package com.lqh.gamespace;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 11, 22);
    private final int CARD = Color.rgb(20, 29, 52);
    private final int CARD_2 = Color.rgb(16, 23, 42);
    private final int ACCENT = Color.rgb(124, 92, 255);
    private final int CYAN = Color.rgb(20, 228, 200);
    private final int RED = Color.rgb(255, 51, 94);
    private final int TEXT = Color.rgb(235, 240, 255);
    private final int MUTED = Color.rgb(154, 166, 205);

    private FrameLayout container;
    private SharedPreferences prefs;
    private String selectedPackage = "";
    private String selectedLabel = "Chưa chọn game";
    private EditText searchInput;
    private LinearLayout appList;
    private List<AppItem> apps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("lqh", MODE_PRIVATE);
        selectedPackage = prefs.getString("selectedPackage", "");
        selectedLabel = prefs.getString("selectedLabel", "Chưa chọn game");
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        container = new FrameLayout(this);
        container.setBackgroundColor(BG);
        setContentView(container);
        showHome();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView tv(String text, float sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setIncludeFontPadding(true);
        return v;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private GradientDrawable strokeBg(int color, float radius, int strokeColor) {
        GradientDrawable g = bg(color, radius);
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private Button btn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(strokeBg(ACCENT, 18, Color.rgb(155, 135, 255)));
        return b;
    }

    private LinearLayout base(String title, String sub) {
        container.removeAllViews();
        LinearLayout vertical = new LinearLayout(this);
        vertical.setOrientation(LinearLayout.VERTICAL);
        vertical.setPadding(dp(16), dp(18), dp(16), dp(10));
        FrameLayout.LayoutParams baseLp = new FrameLayout.LayoutParams(-1, -1);
        container.addView(vertical, baseLp);

        TextView header = tv(title, 26, Color.rgb(143, 118, 255), Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        vertical.addView(header, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = tv(sub, 13, MUTED, Typeface.NORMAL);
        subtitle.setGravity(Gravity.CENTER);
        vertical.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        TextView seal = tv("Bản quyền LQH • No root • No ADB • No Shizuku", 12, CYAN, Typeface.BOLD);
        seal.setGravity(Gravity.CENTER);
        seal.setPadding(0, dp(5), 0, dp(9));
        vertical.addView(seal, new LinearLayout.LayoutParams(-1, -2));
        return vertical;
    }

    private void addBottomNav(LinearLayout root, boolean home) {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(6), dp(8), dp(6));
        nav.setBackground(bg(Color.rgb(15, 22, 44), 24));

        TextView homeBtn = tv("◆ Home", 15, home ? Color.rgb(160, 140, 255) : MUTED, Typeface.BOLD);
        homeBtn.setGravity(Gravity.CENTER);
        TextView boostBtn = tv("⚡ Boost", 15, !home ? Color.rgb(160, 140, 255) : MUTED, Typeface.BOLD);
        boostBtn.setGravity(Gravity.CENTER);
        nav.addView(homeBtn, new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(boostBtn, new LinearLayout.LayoutParams(0, dp(48), 1));
        homeBtn.setOnClickListener(v -> showHome());
        boostBtn.setOnClickListener(v -> showBoost());
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showHome() {
        LinearLayout root = base("LQH Droid Optimizer", "Tối ưu chơi game, nghe nhạc, tải MP3 direct link");
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(4), 0, dp(12));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        content.addView(statusCard());
        content.addView(toggleCard("⚡", "Performance mode", "Giữ màn hình sáng, ưu tiên mở game nhanh", "perf", true));
        content.addView(toggleCard("◎", "Max sensitivity", "Giảm animation trong app, thao tác nhanh hơn", "sensi", true));
        content.addView(toggleCard("■", "RAM boost & cleanup", "Dọn cache của app, nhắc đóng app nền thủ công", "ram", true));
        content.addView(toggleCard("▣", "Battery saver & cooler", "Gợi ý giảm sáng, tắt boost nặng khi máy nóng", "cooler", false));
        content.addView(toggleCard("↯", "Fast charging", "Mở cài đặt pin/sạc của máy", "charge", false));
        content.addView(toggleCard("◈", "Optimize Internet", "Kiểm tra mạng, mở cài đặt Wi‑Fi/Dữ liệu", "net", true));
        content.addView(musicCard());
        addBottomNav(root, true);
    }

    private View statusCard() {
        LinearLayout card = cardBase();
        TextView title = tv("Game đã chọn", 15, MUTED, Typeface.BOLD);
        card.addView(title);
        TextView game = tv(selectedLabel, 23, TEXT, Typeface.BOLD);
        game.setPadding(0, dp(4), 0, dp(8));
        card.addView(game);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button open = btn("Mở game");
        Button boost = btn("Boost VIP");
        Button pick = btn("Chọn game");
        row.addView(open, new LinearLayout.LayoutParams(0, dp(48), 1));
        row.addView(space(8, 1));
        row.addView(boost, new LinearLayout.LayoutParams(0, dp(48), 1));
        row.addView(space(8, 1));
        row.addView(pick, new LinearLayout.LayoutParams(0, dp(48), 1));
        card.addView(row);
        open.setOnClickListener(v -> launchSelected());
        boost.setOnClickListener(v -> runSmartBoost());
        pick.setOnClickListener(v -> showBoost());
        return card;
    }

    private View toggleCard(String icon, String title, String desc, String key, boolean defaultValue) {
        LinearLayout card = cardBase();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);

        TextView ico = tv(icon, 24, key.equals("charge") ? RED : CYAN, Typeface.BOLD);
        ico.setGravity(Gravity.CENTER);
        card.addView(ico, new LinearLayout.LayoutParams(dp(42), dp(62)));

        LinearLayout txts = new LinearLayout(this);
        txts.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 17, TEXT, Typeface.BOLD);
        TextView d = tv(desc, 12, MUTED, Typeface.BOLD);
        txts.addView(t);
        txts.addView(d);
        card.addView(txts, new LinearLayout.LayoutParams(0, -2, 1));

        Switch sw = new Switch(this);
        sw.setChecked(prefs.getBoolean(key, defaultValue));
        card.addView(sw);
        sw.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> {
            prefs.edit().putBoolean(key, isChecked).apply();
            if (key.equals("perf")) {
                if (isChecked) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            if (key.equals("charge") && isChecked) openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            if (key.equals("net") && isChecked) openSettings(Settings.ACTION_WIFI_SETTINGS);
            toast(isChecked ? "Đã bật " + title : "Đã tắt " + title);
        });
        return card;
    }

    private LinearLayout cardBase() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(strokeBg(CARD, 18, Color.rgb(37, 48, 83)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(7));
        card.setLayoutParams(lp);
        return card;
    }

    private View space(int w, int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), dp(h)));
        return v;
    }

    private View musicCard() {
        LinearLayout card = cardBase();
        TextView t = tv("🎧 MP3 Downloader", 18, TEXT, Typeface.BOLD);
        TextView d = tv("Chỉ tải link audio trực tiếp mà bạn có quyền dùng. Không tải/convert từ YouTube, Spotify hoặc link khóa bản quyền.", 12, MUTED, Typeface.BOLD);
        card.addView(t);
        card.addView(d);

        EditText url = input("Dán link .mp3 / .m4a / .wav / .ogg");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        card.addView(url, new LinearLayout.LayoutParams(-1, dp(50)));
        EditText name = input("Tên file: lqh_music.mp3");
        name.setSingleLine(true);
        name.setImeOptions(EditorInfo.IME_ACTION_DONE);
        card.addView(name, new LinearLayout.LayoutParams(-1, dp(50)));
        Button download = btn("Tải về thư mục Music");
        card.addView(download, new LinearLayout.LayoutParams(-1, dp(50)));
        download.setOnClickListener(v -> downloadAudio(url.getText().toString().trim(), name.getText().toString().trim()));
        return card;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(strokeBg(Color.rgb(10, 16, 32), 14, Color.rgb(40, 52, 90)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(0, dp(8), 0, 0);
        e.setLayoutParams(lp);
        return e;
    }

    private void showBoost() {
        LinearLayout root = base("Game Booster", "Speed up và fix lag theo kiểu an toàn, không cần root");
        searchInput = input("Search all apps & games...");
        root.addView(searchInput, new LinearLayout.LayoutParams(-1, dp(54)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> { filterApps(); return false; });
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { filterApps(); }
            public void afterTextChanged(android.text.Editable s) {}
        });

        ScrollView scroll = new ScrollView(this);
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        appList.setPadding(0, dp(6), 0, dp(10));
        scroll.addView(appList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addBottomNav(root, false);
        loadApps();
        filterApps();
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);
        for (ResolveInfo info : infos) {
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            String label = String.valueOf(info.loadLabel(pm));
            Drawable icon = info.loadIcon(pm);
            apps.add(new AppItem(label, pkg, icon));
        }
        Collections.sort(apps, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
    }

    private void filterApps() {
        if (appList == null) return;
        appList.removeAllViews();
        String q = searchInput == null ? "" : searchInput.getText().toString().toLowerCase(Locale.ROOT).trim();
        int count = 0;
        for (AppItem item : apps) {
            if (!q.isEmpty() && !item.label.toLowerCase(Locale.ROOT).contains(q) && !item.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            appList.addView(appRow(item));
            count++;
            if (count >= 80) break;
        }
        if (count == 0) {
            TextView empty = tv("Không tìm thấy app/game. Hãy xoá ô tìm kiếm hoặc cài game trước.", 14, MUTED, Typeface.BOLD);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(22), 0, dp(22));
            appList.addView(empty);
        }
    }

    private View appRow(AppItem item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(strokeBg(CARD_2, 18, Color.rgb(31, 43, 80)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        row.setLayoutParams(lp);

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(item.icon);
        row.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);
        TextView title = tv(item.label, 16, TEXT, Typeface.BOLD);
        TextView pkg = tv(item.pkg, 11, MUTED, Typeface.BOLD);
        texts.addView(title);
        texts.addView(pkg);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        Button add = btn(selectedPackage.equals(item.pkg) ? "Đã chọn" : "GAME");
        row.addView(add, new LinearLayout.LayoutParams(dp(92), dp(44)));
        View.OnClickListener choose = v -> {
            selectedPackage = item.pkg;
            selectedLabel = item.label;
            prefs.edit().putString("selectedPackage", selectedPackage).putString("selectedLabel", selectedLabel).apply();
            toast("Đã chọn: " + selectedLabel);
            showHome();
        };
        add.setOnClickListener(choose);
        row.setOnClickListener(choose);
        return row;
    }

    private void runSmartBoost() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs.edit().putBoolean("perf", true).putBoolean("sensi", true).putBoolean("ram", true).putBoolean("net", true).apply();
        toast("Boost VIP bật: giữ màn hình sáng + profile game. Tối ưu sâu vẫn phụ thuộc Android/máy.");
    }

    private void launchSelected() {
        if (selectedPackage == null || selectedPackage.isEmpty()) {
            toast("Chưa chọn game");
            showBoost();
            return;
        }
        runSmartBoost();
        Intent launch = getPackageManager().getLaunchIntentForPackage(selectedPackage);
        if (launch == null) {
            toast("Không mở được game này");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void downloadAudio(String link, String fileName) {
        if (link.isEmpty() || !(link.startsWith("http://") || link.startsWith("https://"))) {
            toast("Link phải bắt đầu bằng http:// hoặc https://");
            return;
        }
        String lower = link.toLowerCase(Locale.ROOT);
        boolean ok = lower.contains(".mp3") || lower.contains(".m4a") || lower.contains(".wav") || lower.contains(".ogg");
        if (!ok) {
            toast("Chỉ hỗ trợ link audio trực tiếp .mp3/.m4a/.wav/.ogg");
            return;
        }
        if (fileName.isEmpty()) fileName = "lqh_music.mp3";
        fileName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (!fileName.contains(".")) fileName += ".mp3";
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(link));
            request.setTitle(fileName);
            request.setDescription("LQH MP3 Downloader");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, fileName);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(request);
            toast("Đang tải vào thư mục Music");
        } catch (Exception e) {
            toast("Không tải được link này");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static class AppItem {
        String label;
        String pkg;
        Drawable icon;
        AppItem(String label, String pkg, Drawable icon) {
            this.label = label;
            this.pkg = pkg;
            this.icon = icon;
        }
    }
}
