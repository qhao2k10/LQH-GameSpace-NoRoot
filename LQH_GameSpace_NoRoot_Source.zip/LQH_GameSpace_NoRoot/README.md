# LQH GameSpace NoRoot

App Android kiểu **Game Booster / Game Space**: giao diện VIP, chọn game, bật profile chơi game, tải nhạc từ **direct audio link** vào thư mục Music.

## Quan trọng

- No root, no ADB, no Shizuku.
- Không thể làm app no-root tăng thật GPU/RAM/FPS như app hệ thống của hãng. App này làm phần an toàn: chọn game, giữ màn hình sáng, mở game nhanh, mở cài đặt mạng/pin, lưu profile, tải audio direct link.
- Không nhồi APK thành 10GB. APK nên nhỏ để cài nhanh. Nếu tải nhạc/game data, app có thể lưu file vào máy miễn còn đủ dung lượng.
- MP3 Downloader chỉ dùng cho link audio trực tiếp mà bạn có quyền dùng. Không hỗ trợ tải/convert YouTube, Spotify hoặc nội dung khóa bản quyền.

## Build hoàn toàn bằng điện thoại trên GitHub web

1. Vào github.com trên Chrome, đăng nhập.
2. Bấm `+` → `New repository`.
3. Đặt tên ví dụ `LQH-GameSpace-NoRoot` → chọn `Public` hoặc `Private` → `Create repository`.
4. Trên trang repo, bấm `Add file` → `Upload files`.
5. Giải nén file zip này trên điện thoại trước, rồi upload **toàn bộ thư mục và file bên trong** lên repo. Không upload nguyên 1 file zip nếu muốn Actions build.
6. Bấm `Commit changes`.
7. Mở tab `Actions` → chọn `Build Android APK` → `Run workflow`.
8. Đợi build xong, mở job build → mục `Artifacts` → tải `LQH-GameSpace-NoRoot-debug-apk`.
9. Giải nén artifact, cài file `app-debug.apk` trên điện thoại.

## Đổi tên app

- Tên hiển thị: sửa `app/src/main/AndroidManifest.xml`, dòng `android:label="LQH GameSpace"`.
- Package ID: sửa `applicationId` trong `app/build.gradle` và `namespace` nếu cần. Nếu đổi package, nên đổi cả thư mục `app/src/main/java/com/lqh/gamespace` cho đồng bộ.

## Đổi màu/giao diện

Sửa các mã màu đầu file:

`app/src/main/java/com/lqh/gamespace/MainActivity.java`

Ví dụ: `ACCENT`, `CYAN`, `RED`, `CARD`, `BG`.

## File APK ở đâu sau khi build?

Sau khi GitHub Actions chạy xong, APK nằm trong artifact:

`app/build/outputs/apk/debug/app-debug.apk`

